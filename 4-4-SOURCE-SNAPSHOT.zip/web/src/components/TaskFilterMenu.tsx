/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
import { listenForOutsidePointerDown, listenForMenuViewportChange } from "../menuEvents";
import {
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type KeyboardEvent as ReactKeyboardEvent,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { labelDisplayName, labelPresentation } from "../labels";
import {
  taskPriorityLabel,
  taskStatusLabel,
  useTaskboardI18n,
  type TaskboardLanguage,
} from "../i18n";
import {
  EMPTY_TASK_FILTERS,
  matchesTaskFilters,
  matchesTaskSearch,
  taskFilterCount,
  type TaskFilters,
} from "../taskFilters";
import {
  TASK_PRIORITIES,
  TASK_STATUSES,
  type Task,
  type TaskPriority,
  type TaskStatus,
} from "../types";
import { LinearIcon } from "./LinearIcon";
import { LabelIcon, PriorityIcon, StatusIcon } from "./SemanticIcons";
import { TaskboardIcon } from "./TaskboardIcon";

export type TaskSort = "default" | "name" | "priority";

type SubmenuName = "statuses" | "priorities" | "labels" | "sort";

interface TaskFilterMenuProps {
  tasks: Task[];
  search: string;
  labels: string[];
  filters: TaskFilters;
  onChange: (filters: TaskFilters) => void;
  sort: TaskSort;
  onSortChange: (sort: TaskSort) => void;
}

interface FilterOption {
  id: string;
  label: string;
  category: string;
  keywords?: string;
  count: number;
  selected: boolean;
  icon: ReactNode;
  toggle: () => void;
}

function LabelGlyph({ label }: { label: string }) {
  const { language } = useTaskboardI18n();
  const presentation = labelPresentation(label, language);
  if (!presentation.tone) return null;
  return <span className="filter-label-glyph" style={{ "--label-color": presentation.color } as CSSProperties} aria-hidden="true" />;
}

function joinSummary(values: string[], noun: string, language: TaskboardLanguage): string | null {
  if (!values.length) return null;
  if (values.length <= 2) return values.join(language === "zh" ? "、" : ", ");
  return language === "zh" ? `${values.length} 個${noun}` : `${values.length} ${noun}`;
}

export function TaskFilterMenu({ tasks, search, labels, filters, onChange, sort, onSortChange }: TaskFilterMenuProps) {
  const { language, text } = useTaskboardI18n();
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const submenuRef = useRef<HTMLDivElement>(null);
  const hoverTimerRef = useRef<number | null>(null);
  const [open, setOpen] = useState(false);
  const [submenu, setSubmenu] = useState<SubmenuName | null>(null);
  const [rootQuery, setRootQuery] = useState("");
  const [submenuQuery, setSubmenuQuery] = useState("");
  const [position, setPosition] = useState({ left: 0, top: 0, ready: false });
  const [submenuSide, setSubmenuSide] = useState<"left" | "right" | "overlay">("left");
  const [submenuShift, setSubmenuShift] = useState(0);
  const activeCount = taskFilterCount(filters);

  function closeMenu() {
    if (hoverTimerRef.current !== null) window.clearTimeout(hoverTimerRef.current);
    setOpen(false);
    setSubmenu(null);
    setRootQuery("");
    setSubmenuQuery("");
  }

  function openMenu() {
    setRootQuery("");
    setSubmenu(null);
    setPosition((current) => ({ ...current, ready: false }));
    setOpen(true);
  }

  function openSubmenu(name: SubmenuName, focus = false) {
    if (hoverTimerRef.current !== null) window.clearTimeout(hoverTimerRef.current);
    setSubmenu(name);
    setSubmenuQuery("");
    if (focus) {
      requestAnimationFrame(() => submenuRef.current?.querySelector<HTMLElement>("input, button")?.focus());
    }
  }

  function scheduleSubmenu(name: SubmenuName) {
    if (hoverTimerRef.current !== null) window.clearTimeout(hoverTimerRef.current);
    hoverTimerRef.current = window.setTimeout(() => openSubmenu(name), 160);
  }

  const searchMatches = useMemo(() => {
    if (!open) return [];
    const contentFilters = { ...EMPTY_TASK_FILTERS, content: filters.content };
    return tasks.filter((task) => matchesTaskSearch(task, search, language)
      && matchesTaskFilters(task, contentFilters));
  }, [filters.content, language, open, search, tasks]);

  const counts = useMemo(() => {
    const statuses = new Map<TaskStatus, number>();
    const priorities = new Map<TaskPriority, number>();
    const labelCounts = new Map<string, number>();
    const filtersWithoutContent = { ...filters, content: "" };
    for (const task of searchMatches) {
      if (matchesTaskFilters(task, filtersWithoutContent, "statuses")) {
        statuses.set(task.status, (statuses.get(task.status) ?? 0) + 1);
      }
      if (matchesTaskFilters(task, filtersWithoutContent, "priorities")) {
        priorities.set(task.priority, (priorities.get(task.priority) ?? 0) + 1);
      }
      if (matchesTaskFilters(task, filtersWithoutContent, "labels")) {
        for (const label of task.labels) {
          labelCounts.set(label, (labelCounts.get(label) ?? 0) + 1);
        }
      }
    }
    return { statuses, priorities, labels: labelCounts };
  }, [filters, searchMatches]);

  function toggleStatus(status: TaskStatus) {
    const selected = new Set(filters.statuses);
    if (selected.has(status)) selected.delete(status);
    else selected.add(status);
    onChange({ ...filters, statuses: TASK_STATUSES.filter((value) => selected.has(value)) });
  }

  function togglePriority(priority: TaskPriority) {
    const selected = new Set(filters.priorities);
    if (selected.has(priority)) selected.delete(priority);
    else selected.add(priority);
    onChange({ ...filters, priorities: TASK_PRIORITIES.filter((value) => selected.has(value)) });
  }

  function toggleLabel(label: string) {
    const selected = new Set(filters.labels);
    if (selected.has(label)) selected.delete(label);
    else selected.add(label);
    onChange({ ...filters, labels: labels.filter((value) => selected.has(value)) });
  }

  const statusOptions = useMemo<FilterOption[]>(() => TASK_STATUSES.map((status) => ({
    id: `status-${status}`,
    label: taskStatusLabel(language, status),
    category: text("狀態", "Status"),
    keywords: status,
    count: counts.statuses.get(status) ?? 0,
    selected: filters.statuses.includes(status),
    icon: <span className="filter-status-icon"><StatusIcon status={status} color="currentColor" /></span>,
    toggle: () => toggleStatus(status),
  })), [counts, filters, language, text]);

  const priorityOptions = useMemo<FilterOption[]>(() => TASK_PRIORITIES.map((priority) => ({
    id: `priority-${priority}`,
    label: taskPriorityLabel(language, priority),
    category: text("優先順序", "Priority"),
    keywords: priority,
    count: counts.priorities.get(priority) ?? 0,
    selected: filters.priorities.includes(priority),
    icon: <PriorityIcon priority={priority} />,
    toggle: () => togglePriority(priority),
  })), [counts, filters, language, text]);

  const labelOptions = useMemo<FilterOption[]>(() => labels.map((label) => ({
    id: `label-${label}`,
    label: labelDisplayName(label, language),
    category: text("標籤", "Label"),
    count: counts.labels.get(label) ?? 0,
    selected: filters.labels.includes(label),
    icon: <LabelGlyph label={label} />,
    toggle: () => toggleLabel(label),
  })), [counts, filters, labels, language, text]);

  const optionsBySubmenu: Partial<Record<SubmenuName, FilterOption[]>> = {
    statuses: statusOptions,
    priorities: priorityOptions,
    labels: labelOptions,
  };

  const sortOptions: { value: TaskSort; label: string }[] = [
    { value: "default", label: text("預設排序", "Default order") },
    { value: "name", label: text("名稱排序", "Name order") },
    { value: "priority", label: text("優先順序排序", "Priority order") },
  ];

  const categories = [
    {
      id: "statuses" as const,
      label: text("狀態", "Status"),
      keywords: "status state",
      icon: <StatusIcon status="todo" color="currentColor" />,
      summary: joinSummary(
        filters.statuses.map((status) => taskStatusLabel(language, status)),
        text("狀態", "statuses"),
        language,
      ),
    },
    {
      id: "priorities" as const,
      label: text("優先順序", "Priority"),
      keywords: "priority urgent high medium low",
      icon: <PriorityIcon color="currentColor" />,
      summary: joinSummary(
        filters.priorities.map((priority) => taskPriorityLabel(language, priority)),
        text("優先順序", "priorities"),
        language,
      ),
    },
    {
      id: "labels" as const,
      label: text("標籤", "Labels"),
      keywords: "label tag",
      icon: <LabelIcon color="currentColor" />,
      summary: joinSummary(
        filters.labels.map((label) => labelDisplayName(label, language)),
        text("標籤", "labels"),
        language,
      ),
    },
    {
      id: "sort" as const,
      label: text("排序", "Sort"),
      keywords: "sort order name priority 預設 名稱 優先順序",
      icon: <LinearIcon name="displayOptions" />,
      summary: sortOptions.find((option) => option.value === sort)?.label ?? null,
    },
  ];

  const normalizedRootQuery = rootQuery.trim().toLowerCase();
  const visibleCategories = categories.filter((category) => {
    if (!normalizedRootQuery) return true;
    return `${category.label} ${category.keywords}`.toLowerCase().includes(normalizedRootQuery);
  });
  const quickOptions = normalizedRootQuery
    ? [...statusOptions, ...priorityOptions, ...labelOptions].filter((option) =>
      `${option.label} ${option.keywords ?? ""}`.toLowerCase().includes(normalizedRootQuery),
    )
    : [];

  useEffect(() => {
    function handleShortcut(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target?.matches("input, textarea, select, [contenteditable='true']")) return;
      if (event.key.toLowerCase() === "f" && !event.metaKey && !event.ctrlKey && !event.altKey) {
        event.preventDefault();
        open ? closeMenu() : openMenu();
      }
    }

    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, [open]);

  useLayoutEffect(() => {
    if (!open || !triggerRef.current || !menuRef.current) return;
    const triggerRect = triggerRef.current.getBoundingClientRect();
    const menuRect = menuRef.current.getBoundingClientRect();
    const left = Math.max(8, Math.min(triggerRect.right - menuRect.width, window.innerWidth - menuRect.width - 8));
    const below = triggerRect.bottom + 6;
    const top = below + menuRect.height <= window.innerHeight - 8
      ? below
      : Math.max(8, triggerRect.top - menuRect.height - 6);
    const rightSpace = window.innerWidth - (left + menuRect.width);
    setPosition({ left, top, ready: true });
    setSubmenuSide(
      rightSpace >= menuRect.width + 4
        ? "right"
        : left >= menuRect.width + 12
          ? "left"
          : "overlay",
    );
  }, [activeCount, open, normalizedRootQuery]);

  useLayoutEffect(() => {
    if (!submenu || !submenuRef.current) {
      setSubmenuShift(0);
      return;
    }
    const rect = submenuRef.current.getBoundingClientRect();
    const shift = rect.bottom > window.innerHeight - 8
      ? window.innerHeight - 8 - rect.bottom
      : rect.top < 8
        ? 8 - rect.top
        : 0;
    setSubmenuShift(shift);
  }, [filters, submenu, submenuQuery]);

  useEffect(() => {
    if (!open) return;
    requestAnimationFrame(() => menuRef.current?.querySelector<HTMLInputElement>(".task-filter-search input")?.focus());

    const stopOutside = listenForOutsidePointerDown([menuRef, triggerRef], closeMenu);
    const stopViewport = listenForMenuViewportChange(menuRef, closeMenu);

    return () => {
      stopOutside();
      stopViewport();
    };
  }, [open]);

  useEffect(() => () => {
    if (hoverTimerRef.current !== null) window.clearTimeout(hoverTimerRef.current);
  }, []);

  function focusSibling(button: HTMLButtonElement, direction: 1 | -1) {
    const level = button.dataset.filterLevel;
    const buttons = Array.from(menuRef.current?.querySelectorAll<HTMLButtonElement>(
      `button[data-filter-level="${level}"]:not(:disabled)`,
    ) ?? []);
    const index = buttons.indexOf(button);
    buttons[(Math.max(0, index) + direction + buttons.length) % buttons.length]?.focus();
  }

  function handleMenuKeyDown(event: ReactKeyboardEvent<HTMLDivElement>) {
    const target = event.target as HTMLElement;
    if (event.key === "Escape") {
      event.preventDefault();
      if (submenu) {
        const owner = submenu;
        setSubmenu(null);
        requestAnimationFrame(() => menuRef.current?.querySelector<HTMLButtonElement>(`[data-submenu-name="${owner}"]`)?.focus());
      } else {
        closeMenu();
        triggerRef.current?.focus();
      }
      return;
    }

    if (event.key === "Tab") {
      const focusable = Array.from(menuRef.current?.querySelectorAll<HTMLElement>("input:not(:disabled), button:not(:disabled)") ?? [])
        .filter((element) => element.getClientRects().length > 0);
      const index = focusable.indexOf(target);
      const direction = event.shiftKey ? -1 : 1;
      if (focusable.length) {
        event.preventDefault();
        focusable[(Math.max(0, index) + direction + focusable.length) % focusable.length]?.focus();
      }
      return;
    }

    if (target instanceof HTMLInputElement && (event.key === "ArrowDown" || event.key === "ArrowUp")) {
      const level = target.dataset.filterLevel;
      const buttons = Array.from(menuRef.current?.querySelectorAll<HTMLButtonElement>(
        `button[data-filter-level="${level}"]:not(:disabled)`,
      ) ?? []);
      if (buttons.length) {
        event.preventDefault();
        (event.key === "ArrowDown" ? buttons[0] : buttons.at(-1))?.focus();
      }
      return;
    }

    const button = target.closest<HTMLButtonElement>("button[data-filter-level]");
    if (!button) return;
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      focusSibling(button, event.key === "ArrowDown" ? 1 : -1);
    } else if (event.key === "ArrowRight" && button.dataset.submenuName) {
      event.preventDefault();
      openSubmenu(button.dataset.submenuName as SubmenuName, true);
    } else if (event.key === "ArrowLeft" && button.dataset.filterLevel === "submenu") {
      event.preventDefault();
      const owner = submenu;
      setSubmenu(null);
      requestAnimationFrame(() => menuRef.current?.querySelector<HTMLButtonElement>(`[data-submenu-name="${owner}"]`)?.focus());
    }
  }

  function renderOption(option: FilterOption, level: "root" | "submenu") {
    return (
      <button
        key={option.id}
        type="button"
        role="menuitemcheckbox"
        aria-checked={option.selected}
        className={`task-filter-item filter-value-item${option.selected ? " is-selected" : ""}`}
        data-filter-level={level}
        onPointerEnter={() => {
          if (level === "root") setSubmenu(null);
        }}
        onClick={option.toggle}
      >
        <span className="task-filter-item-icon">{option.icon}</span>
        <span className="task-filter-item-label">{option.label}</span>
        {level === "root" && <span className="task-filter-item-category">{option.category}</span>}
        <span className="task-filter-item-count">{option.count}</span>
        <span className="task-filter-item-check">{option.selected && <LinearIcon name="check" />}</span>
      </button>
    );
  }

  function renderValueSubmenu(name: SubmenuName) {
    if (name === "sort") {
      return (
        <div className="task-filter-scroll" role="menu">
          {sortOptions.map((option) => (
            <button
              key={option.value}
              type="button"
              role="menuitemradio"
              aria-checked={sort === option.value}
              className={`task-filter-item filter-value-item${sort === option.value ? " is-selected" : ""}`}
              data-filter-level="submenu"
              onClick={() => { onSortChange(option.value); closeMenu(); }}
            >
              <span className="task-filter-item-label">{option.label}</span>
              <span className="task-filter-item-check">{sort === option.value && <LinearIcon name="check" />}</span>
            </button>
          ))}
        </div>
      );
    }
    const options = optionsBySubmenu[name] ?? [];
    const needle = submenuQuery.trim().toLowerCase();
    const visible = options.filter((option) => `${option.label} ${option.keywords ?? ""}`.toLowerCase().includes(needle));
    const matching = visible.filter((option) => option.count > 0 || option.selected);
    const unmatched = visible.filter((option) => option.count === 0 && !option.selected);

    return (
      <>
        <label className="task-filter-search submenu-filter-search">
          <span className="sr-only">{text("篩選值", "Filter values")}</span>
          <input
            data-filter-level="submenu"
            value={submenuQuery}
            onChange={(event) => setSubmenuQuery(event.target.value)}
            placeholder={text("篩選…", "Filter…")}
          />
        </label>
        <div className="task-filter-scroll" role="menu">
          {matching.map((option) => renderOption(option, "submenu"))}
          {unmatched.length > 0 && (
            <>
              <div className="task-filter-section-label">{text("目前檢視中無匹配", "No matches in this view")}</div>
              <div className="task-filter-unmatched">{unmatched.map((option) => renderOption(option, "submenu"))}</div>
            </>
          )}
          {visible.length === 0 && <div className="task-filter-no-results">{text("沒有匹配的篩選值", "No matching filter values")}</div>}
        </div>
      </>
    );
  }

  const menu = open ? createPortal(
    <div
      ref={menuRef}
      className="task-filter-menu"
      data-has-submenu={submenu ? "true" : undefined}
      data-submenu-side={submenuSide}
      style={{ left: position.left, top: position.top, visibility: position.ready ? "visible" : "hidden" }}
      onKeyDown={handleMenuKeyDown}
    >
      <label className="task-filter-search root-filter-search">
        <span className="sr-only">{text("新增篩選", "Add filter")}</span>
        <input
          data-filter-level="root"
          value={rootQuery}
          onChange={(event) => {
            setRootQuery(event.target.value);
            setSubmenu(null);
          }}
          placeholder={text("新增篩選…", "Add filter…")}
        />
        <kbd>F</kbd>
      </label>

      <div className="task-filter-root-list" role="menu">
        {visibleCategories.map((category) => (
          <div className="task-filter-anchor" key={category.id}>
            <button
              type="button"
              role="menuitem"
              aria-haspopup="menu"
              aria-expanded={submenu === category.id}
              className={`task-filter-item task-filter-category${submenu === category.id ? " is-open" : ""}${category.summary ? " is-active" : ""}`}
              data-filter-level="root"
              data-submenu-name={category.id}
              onPointerEnter={() => scheduleSubmenu(category.id)}
              onClick={() => submenu === category.id ? setSubmenu(null) : openSubmenu(category.id, true)}
            >
              <span className="task-filter-item-icon">{category.icon}</span>
              <span className="task-filter-item-label">{category.label}</span>
              {category.summary && <span className="task-filter-item-summary">{category.summary}</span>}
              <span className="task-filter-chevron"><LinearIcon name="chevronRight" /></span>
            </button>

            {submenu === category.id && (
              <div
                ref={submenuRef}
                className="task-filter-submenu"
                role="presentation"
                style={{ "--submenu-shift": `${submenuShift}px` } as CSSProperties}
              >
                {renderValueSubmenu(category.id)}
              </div>
            )}
          </div>
        ))}

        {quickOptions.length > 0 && (
          <>
            {visibleCategories.length > 0 && <div className="task-filter-section-label">{text("篩選值", "Filter values")}</div>}
            {quickOptions.map((option) => renderOption(option, "root"))}
          </>
        )}

        {visibleCategories.length === 0 && quickOptions.length === 0 && (
          <div className="task-filter-no-results">{text("沒有匹配的篩選項", "No matching filters")}</div>
        )}
      </div>

      {activeCount > 0 && (
        <div className="task-filter-footer">
          <button
            type="button"
            className="task-filter-clear-all"
            data-filter-level="root"
            onClick={() => onChange(EMPTY_TASK_FILTERS)}
          >
            {text("清除所有篩選", "Clear all filters")}
            <span>{activeCount}</span>
          </button>
        </div>
      )}
    </div>,
    document.body,
  ) : null;

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        className={`task-filter-trigger${activeCount ? " is-active" : ""}${open ? " is-open" : ""}`}
        aria-label={activeCount
          ? text(`篩選任務，已啟用 ${activeCount} 個條件`, `Filter issues, ${activeCount} active`)
          : text("篩選任務", "Filter issues")}
        aria-haspopup="menu"
        aria-expanded={open}
        title={activeCount
          ? text(`已啟用 ${activeCount} 個篩選條件 (F)`, `${activeCount} active filters (F)`)
          : text("篩選任務 (F)", "Filter issues (F)")}
        onClick={() => open ? closeMenu() : openMenu()}
      >
        <TaskboardIcon name="filter" className="filter-icon" />
        {activeCount > 0 && <span className="task-filter-active-dot" aria-hidden="true" />}
      </button>
      {menu}
    </>
  );
}
