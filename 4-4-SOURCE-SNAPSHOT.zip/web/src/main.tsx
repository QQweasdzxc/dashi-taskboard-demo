/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { SupabaseRoot } from "./supabase/SupabaseRoot";
import { initializeTaskboardStorage } from "./storage";
import "./styles.css";

async function main() {
  await initializeTaskboardStorage();
  createRoot(document.getElementById("root")!).render(
    <StrictMode>
      <SupabaseRoot />
    </StrictMode>,
  );
}

void main();
