/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
// TF transport projection only. Original fields remain unchanged in Supabase.
export function projectSnapshot(list:any,display:any){
 if(!Array.isArray(list?.issues)||!Array.isArray(display?.projects)||!Array.isArray(display?.statuses))throw Error('正式來源形狀不符，未顯示資料');
 const issues=list.issues.map((x:any)=>({...x,project_id:x.project_id??display.issue_projects?.[x.id]??null}));
 const projects=display.projects.map((p:any)=>({id:p.id,name:p.title,workspacePath:null,source:'local',labels:[...new Set(issues.filter((i:any)=>i.project_id===p.id).flatMap((i:any)=>(i.labels||[]).map((l:any)=>l.name)))],issueCount:issues.filter((i:any)=>i.project_id===p.id).length,createdAt:null,updatedAt:null}));
 // Upstream's reserved local means unfiled, not a second database.
 projects.unshift({id:'local',name:'未分類任務',workspacePath:null,source:'local',labels:[],issueCount:issues.filter((i:any)=>!i.project_id).length,createdAt:null,updatedAt:null});
 const statuses=[...display.statuses];for(const i of issues)if(!statuses.some((s:any)=>s.key===i.status))statuses.push({key:i.status,name:i.status,category:'unknown',color:null});
 return {issues,projects,statuses,preferences:display.preferences||[],prefix:list.prefix,workspaceId:display.workspace_id};
}
export function taskProjection(i:any,prefix:string){return {id:i.id,identifier:prefix+'-'+i.number,projectId:i.project_id||'local',title:i.title,description:i.description??'',status:i.status,priority:i.priority,labels:(i.labels||[]).map((l:any)=>l.name),sortOrder:i.position??0,threadId:null,threadBinding:null,legacyLocalThreadId:null,agentSession:null,conversationRefs:[],participants:[],previewImage:null,activityKey:String(i.revision),activityUpdatedAt:i.last_activity_at??i.updated_at??i.created_at??null,creatorType:i.creator_type==='agent'?'agent':'user',creatorId:i.creator_id??'',creatorName:'未提供',creatorAvatarUrl:null,assignee:{type:i.assignee_type==='agent'?'agent':'user',id:i.assignee_id??'',name:i.assignee_id?'未提供名稱':'未指派',avatarUrl:null},developmentContext:null,startDate:i.start_date??null,dueDate:i.due_date??null,recurrence:null,source:'local',externalOrigin:null,externalKey:null,externalUrl:null,archivedAt:null,relations:{parent:null,subIssues:[],blockedBy:[],blocks:[],related:[]},version:i.revision,createdAt:i.created_at??null,updatedAt:i.updated_at??i.created_at??null,tfOriginal:i};}

// Scope status choices to the selected project. Preserve unknown statuses in use.
export function scopedStatuses(snapshot:any,project:string|null){
 if(!snapshot)return [];
 const scoped=project&&project!=='__all_projects__';
 const rows=scoped?snapshot.issues.filter((i:any)=>(i.project_id||'local')===project):snapshot.issues;
 const used=new Set(rows.map((i:any)=>i.status));
 const prefs=scoped?snapshot.preferences?.find((p:any)=>p.scope_type==='project'&&p.scope_id===project):null;
 const canon=(key:string)=>key.startsWith('TF:')?key.slice(3):key;
 const labels=prefs?.status_labels||{},order=prefs?.status_order||[];
 const owned=new Set([...Object.keys(labels),...order].map(canon));
 const otherOwned=new Set((snapshot.preferences||[]).filter((p:any)=>p.scope_type==='project'&&p.scope_id!==project).flatMap((p:any)=>[...Object.keys(p.status_labels||{}),...(p.status_order||[])].map(canon)));
 const hidden=new Set((prefs?.hidden_statuses||[]).map(canon));
 return snapshot.statuses.filter((s:any)=>{
  if(used.has(s.key))return true;
  if(s.archived_at||hidden.has(canon(s.key)))return false;
  if(!scoped)return true;
  if(owned.has(canon(s.key)))return true;
  if(otherOwned.has(canon(s.key)))return false;
  return s.is_system===true||(!s.key.startsWith('TF:')&&s.is_system!==false);
 }).map((s:any)=>({...s,name:labels[s.key]||labels[canon(s.key)]||s.name,hiddenByPreference:hidden.has(canon(s.key))})).sort((a:any,b:any)=>{
 const ai=order.findIndex((k:string)=>canon(k)===canon(a.key)),bi=order.findIndex((k:string)=>canon(k)===canon(b.key));
 return (ai<0?10000:ai)-(bi<0?10000:bi);
 });
}
