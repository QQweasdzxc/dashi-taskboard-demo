import assert from "node:assert/strict";
import { test } from "node:test";

import {
  AI_CHAT_SKILL_MARKER,
  aiChatEventStatus,
  buildThreadCreateInput,
  buildTurnInput,
  chatPrimaryAction,
  createAiSnapshotRefreshQueue,
  filterVisibleAiEvents,
  needsDangerConfirmation,
  normalizeChatSelection,
  parseAiChatComposerFragment,
  patchAiChatSnapshot,
} from "../web/src/aiChatState.ts";

const models = [
  {
    slug: "codex-real-model",
    displayName: "Codex Real Model",
    description: "Host model",
    defaultReasoningEffort: "high",
    supportedReasoningEfforts: ["medium", "high"],
    serviceTiers: [{ id: "priority", name: "Priority" }],
  },
  {
    slug: "codex-fast-model",
    displayName: "Codex Fast Model",
    description: "Fast host model",
    defaultReasoningEffort: "low",
    supportedReasoningEfforts: ["low"],
    serviceTiers: [],
  },
];

test("new threads freeze the current project and optional issue as server identifiers", () => {
  assert.deepEqual(buildThreadCreateInput("project-1", "issue-1"), {
    projectId: "project-1",
    issueId: "issue-1",
  });
  assert.deepEqual(buildThreadCreateInput("project-1", null), {
    projectId: "project-1",
  });
  assert.equal(buildThreadCreateInput("", null), null);
});

test("PATCH results can update only the snapshot for the thread that started the request", () => {
  const threadA = {
    id: "thread-a",
    title: "A",
    status: "idle",
    origin: { projectId: "project-a" },
  };
  const threadB = {
    id: "thread-b",
    title: "B",
    status: "idle",
    origin: { projectId: "project-b" },
  };
  const current = { thread: threadB, events: [], runs: [] };

  assert.equal(patchAiChatSnapshot(current, "thread-a", threadA), current);
  assert.deepEqual(patchAiChatSnapshot(current, "thread-b", {
    ...threadB,
    title: "B updated",
  }), {
    ...current,
    thread: { ...threadB, title: "B updated" },
  });
});

test("model and effort selections are restricted to the real catalog", () => {
  assert.deepEqual(normalizeChatSelection(models, "codex-real-model", "medium"), {
    model: "codex-real-model",
    reasoningEffort: "medium",
  });
  assert.deepEqual(normalizeChatSelection(models, "codex-real-model", "fake-effort"), {
    model: "codex-real-model",
    reasoningEffort: "high",
  });
  assert.deepEqual(normalizeChatSelection(models, "missing-model", "high"), {
    model: "codex-real-model",
    reasoningEffort: "high",
  });
  assert.equal(normalizeChatSelection([], "missing-model", "high"), null);
});

test("skill composer fragments keep opaque markers aligned with selected real ids", () => {
  assert.deepEqual(parseAiChatComposerFragment(JSON.stringify({
    message: `请用 ${AI_CHAT_SKILL_MARKER} 检查`,
    skillIds: ["cloudflare"],
  }), ["cloudflare"]), {
    message: `请用 ${AI_CHAT_SKILL_MARKER} 检查`,
    skillIds: ["cloudflare"],
  });
});

test("turn input cannot contain cwd, hidden context, model overrides or arbitrary args", () => {
  const input = buildTurnInput(`检查 ${AI_CHAT_SKILL_MARKER} LOCAL-103`, ["cloudflare"], false);
  assert.deepEqual(input, {
    message: `检查 ${AI_CHAT_SKILL_MARKER} LOCAL-103`,
    skillIds: ["cloudflare"],
  });
  assert.equal(JSON.stringify(input).includes("workspacePath"), false);
  assert.equal(JSON.stringify(input).includes("manage-taskboard"), false);
  assert.equal(JSON.stringify(input).includes("model"), false);
  assert.deepEqual(buildTurnInput("执行", [], true), {
    message: "执行",
    dangerFullAccessConfirmed: true,
  });
});

test("visible activity keeps only the latest lifecycle item without merging messages", () => {
  const events = filterVisibleAiEvents([
    {
      id: "1",
      type: "agent_message",
      role: "assistant",
      content: "公开回复一",
      data: { itemId: "shared-message" },
    },
    {
      id: "2",
      type: "agent_message",
      role: "assistant",
      content: "公开回复二",
      data: { itemId: "shared-message" },
    },
    {
      id: "3",
      type: "command_execution",
      role: "activity",
      content: "npm test",
      data: { itemId: "command-1", status: "started" },
    },
    {
      id: "4",
      type: "command_execution",
      role: "activity",
      content: "npm test",
      data: { itemId: "command-1", status: "in_progress" },
    },
    {
      id: "5",
      type: "command_execution",
      role: "activity",
      content: "npm test",
      data: { itemId: "command-1", status: "completed" },
    },
    { id: "6", type: "todo_list", role: "activity", content: "完成测试" },
    { id: "7", type: "turn.failed", role: "error", content: "执行失败" },
    { id: "8", type: "user_message", role: "user", content: "第一条", data: { itemId: "user-1" } },
    { id: "9", type: "user_message", role: "user", content: "第二条", data: { itemId: "user-1" } },
    { id: "10", type: "reasoning", role: "activity", content: "private chain of thought" },
    { id: "11", type: "raw_jsonl", role: "activity", content: "{\"secret\":true}" },
  ]);
  assert.deepEqual(events.map((event) => event.id), ["1", "2", "5", "6", "7", "8", "9"]);
});

test("activity status treats started, running and in_progress as active and failures as failed", () => {
  assert.equal(aiChatEventStatus({
    id: "1",
    type: "command_execution",
    role: "activity",
    content: "",
    data: { status: "started" },
  }), "running");
  assert.equal(aiChatEventStatus({
    id: "2",
    type: "todo_list",
    role: "activity",
    content: "",
    data: { status: "in_progress" },
  }), "running");
  assert.equal(aiChatEventStatus({
    id: "3",
    type: "turn.failed",
    role: "error",
    content: "failed",
  }), "failed");
  assert.equal(aiChatEventStatus({
    id: "4",
    type: "file_change",
    role: "activity",
    content: "",
    data: { status: "completed" },
  }), "completed");
  assert.equal(aiChatEventStatus({
    id: "5",
    type: "error",
    role: "activity",
    content: "Skill descriptions were shortened",
    data: { status: "warning" },
  }), "completed");
});

test("snapshot hint refreshes allow one in-flight request and one queued request", async () => {
  const calls = [];
  const releases = [];
  const queue = createAiSnapshotRefreshQueue(async (threadId) => {
    calls.push(threadId);
    await new Promise((resolve) => releases.push(resolve));
  });

  const first = queue.request("thread-1");
  const queued = [
    queue.request("thread-1"),
    queue.request("thread-1"),
    queue.request("thread-1"),
  ];
  assert.deepEqual(calls, ["thread-1"]);

  releases.shift()();
  await new Promise((resolve) => setImmediate(resolve));
  assert.deepEqual(calls, ["thread-1", "thread-1"]);

  releases.shift()();
  await Promise.all([first, ...queued]);
  assert.deepEqual(calls, ["thread-1", "thread-1"]);
  queue.clear();
});

test("reasoning and raw JSONL events are excluded from the visible timeline", () => {
  const events = filterVisibleAiEvents([
    { id: "1", type: "agent_message", role: "assistant", content: "公开回复" },
    { id: "2", type: "reasoning", role: "activity", content: "private chain of thought" },
    { id: "3", type: "raw_jsonl", role: "activity", content: "{\"secret\":true}" },
    { id: "4", type: "command", role: "activity", content: "npm test" },
  ]);
  assert.deepEqual(events.map((event) => event.id), ["1", "4"]);
});
