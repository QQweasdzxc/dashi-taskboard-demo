import {useState} from 'react';
import type {Task} from '../types';
import {saveTFLabel} from './connection';
export function TFLabels({task,onSaved,locked=false,onBusy}:{task:Task,onSaved:(task:Task)=>void,locked?:boolean,onBusy?:(busy:boolean)=>void}){
 const[busy,setBusy]=useState(false),[error,setError]=useState('');
 const labels:{id:string,name:string,color:string}[]=task.tfOriginal?.label_catalog||[];
 if(!labels.length)return null;
 const toggle=async(id:string,detach:boolean)=>{if(busy||locked)return;setBusy(true);onBusy?.(true);setError('');try{onSaved(await saveTFLabel(task.id,task.version,id,detach)as Task);}catch(e){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);onBusy?.(false);}};
 return <section className="tf-label-editor" aria-label="原 TF 標籤"><h2>標籤</h2>{labels.map(l=>{const checked=task.tfOriginal?.labels?.some((x:any)=>x.id===l.id)??task.labels.includes(l.name);return <label key={l.id}><input type="checkbox" checked={checked} disabled={busy||locked} onChange={()=>void toggle(l.id,checked)}/><span style={{borderColor:l.color}}>{l.name}</span></label>;})}{error&&<p role="alert">{error}</p>}</section>;
}
