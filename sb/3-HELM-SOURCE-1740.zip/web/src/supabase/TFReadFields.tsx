/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
import type {Task} from '../types';
import {currentSnapshot,statusLabel} from './connection';

function scalar(value:unknown):string {
  if(value===null)return '未設定（來源為空值）';
  if(typeof value==='boolean')return value?'是':'否';
  return String(value);
}
function structured(value:unknown):boolean {
  return value!==null&&typeof value==='object';
}
export function TFReadFields({task}:{task:Task}){
  const raw=task.tfOriginal;
  if(!raw)return null;
  const has=(key:string)=>Object.prototype.hasOwnProperty.call(raw,key);
  const row=(key:string,label:string,display?:string)=>has(key)?<div key={key}><dt>{label}</dt><dd>{display??scalar(raw[key])}</dd></div>:null;
  const originalTasks=currentSnapshot()?.issues??[];
  const parent=has('parent_issue_id')&&raw.parent_issue_id?originalTasks.find((i:any)=>i.id===raw.parent_issue_id):null;
  const parentText=raw.parent_issue_id?(parent?`${currentSnapshot().prefix}-${parent.number} ${parent.title}`:`原任務 ID：${raw.parent_issue_id}`):undefined;
  const project=currentSnapshot()?.projects.find((p:any)=>p.id===task.projectId);
  return <details className="tf-fields" aria-label="TF原任務欄位"><summary>原任務資訊與進階欄位</summary>

    <dl>
      <div><dt>編號</dt><dd>{task.identifier}</dd></div>
      {row('status','狀態',statusLabel(raw.status))}
      {row('priority','優先度',raw.priority===0?'0（原值）':scalar(raw.priority))}
      {row('project_id','專案',project?.name??undefined)}
      {row('start_date','開始日期')}{row('due_date','到期日期')}
      {row('parent_issue_id','父任務',parentText)}
    </dl>
    <details><summary>進階與原始資訊</summary><dl>{row('assignee_type','指派類型')}{row('assignee_id','指派對象 ID')}{row('triage_state','分流狀態')}{row('stage','階段')}{row('creator_type','建立者類型')}{row('creator_id','建立者 ID')}{row('created_at','建立時間')}{row('updated_at','更新時間')}{row('last_activity_at','最近活動')}{row('first_executed_at','首次執行時間')}{row('duplicate_of_issue_id','重複任務來源 ID')}</dl></details>
    {has('acceptance_criteria')&&raw.acceptance_criteria!==null&&<div className="tf-criteria"><h3>驗收條件</h3><pre>{structured(raw.acceptance_criteria)?JSON.stringify(raw.acceptance_criteria,null,2):scalar(raw.acceptance_criteria)}</pre></div>}
    {['properties','context_refs','metadata'].filter(has).map(key=><details key={key}><summary>{{properties:'自訂屬性',context_refs:'上下文參照',metadata:'原任務中繼資料'}[key]}（原值）</summary><pre>{JSON.stringify(raw[key],null,2)}</pre></details>)}
    <p className="tf-source-note">僅顯示目前原資料回傳的欄位。尚未提供的身分名稱、附件、依賴與週期資訊不作推測。</p>
  </details>;
}
