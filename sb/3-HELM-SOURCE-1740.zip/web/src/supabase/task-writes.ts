/* HELM task-only candidate, review only. No automatic submission or retry. */
export const taskWrites=import.meta.env.VITE_HELM_TASK_WRITES==='review-candidate';
type Pending={operation:string,requestId:string,issueId:string|null};
const workspace='01a1247f-520e-78eb-aa58-0a0e458185f6';
let key='';
export function bindTaskActor(actor:string|null){key=actor?'trqn_helm_task_pending_20261126_v1:'+actor+':'+workspace:'';}
const endpoints:Record<string,string>={create:'issue_create',update:'issue_basic_update',move:'issue_move',comment:'comment_create'};
const recovery:Record<string,string>={create:'issue_create_recover',update:'issue_basic_update_recover',move:'issue_move_recover',comment:'comment_recover'};
const uuid=(x:any)=>typeof x==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
export function taskPending():Pending|null{if(!key)return null;const raw=localStorage.getItem(key);if(!raw)return null;const m=JSON.parse(raw);if(!m||Object.keys(m).sort().join(',')!=='issueId,operation,requestId'||!endpoints[m.operation]||!uuid(m.requestId)||(m.issueId!==null&&!uuid(m.issueId)))throw Error('待確認紀錄無法驗證，已暫停寫入，原紀錄保留');return m;}
function checkLegacy(){for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i)||'';if(k.startsWith('ownboard.')&&k.includes('pending')&&localStorage.getItem(k))throw Error('舊版有待確認操作，請先查回，未另送新請求');}}
function receipt(r:any,m:Pending){if(!r||r.request_id!==m.requestId||!['committed','terminal_rejected','finalized_absent'].includes(r.state)||(m.issueId&&r.issue_id!==m.issueId)||(r.state==='committed'&&!uuid(r.issue_id)))throw Error('操作回條尚無法驗證');if(r.state==='committed'&&m.operation==='create'&&(!Number.isSafeInteger(r.number)||r.number<1))throw Error('新任務識別不符');if(r.state==='committed'&&m.operation==='comment'&&!uuid(r.comment_id))throw Error('留言識別不符');return r;}
export async function submitTask(operation:string,issueId:string|null,body:any,deps:any){
 if(!key)throw Error('請先登入');
 if(!taskWrites||!endpoints[operation])throw Error('任務寫入尚未開放');
 if(!navigator.locks)throw Error('此瀏覽器無法安全協調跨頁操作，未送出');
 const storageKey=key;return navigator.locks.request(storageKey,{ifAvailable:true},async lock=>{if(!lock)throw Error('其他分頁操作中，未另送出');checkLegacy();if(taskPending())throw Error('前次操作待確認，請先查回，未重新送出');await deps.verify();const g=deps.generation();const m:Pending={operation,requestId:crypto.randomUUID(),issueId};localStorage.setItem(storageKey,JSON.stringify(m));if(localStorage.getItem(storageKey)!==JSON.stringify(m))throw Error('無法保留查回識別，未送出');
 try{const r=receipt(await deps.rpc('ownboard_owner_'+endpoints[operation]+'_20261126_v1',{...body,p_request_id:m.requestId}),m);if(g!==deps.generation())throw Error('登入已改變');await confirm(r,m,deps);if(g!==deps.generation())throw Error('登入已改變');localStorage.removeItem(storageKey);if(r.state==='terminal_rejected')return {...r,userMessage:r.reason_code==='40001'?'原任務已改變，請重新讀取後再操作':'此次操作不符合原任務流程，未儲存'};return r;}catch{throw Error('操作結果待確認。保留請求識別，請按「查回前次操作」，勿重新送出。');}});
}
async function confirm(r:any,m:Pending,deps:any){if(r.state!=='committed')return;const d=await deps.read(r.issue_id);if(d?.issue?.id!==r.issue_id)throw Error('任務尚未讀回');if(r.revision&&d.issue.revision<r.revision)throw Error('版本尚未讀回');if(r.issue_revision&&d.issue.revision<r.issue_revision)throw Error('留言版本尚未讀回');if(m.operation==='comment'&&!d.comments?.some((c:any)=>c.id===r.comment_id))throw Error('留言尚未讀回');if(m.operation==='create'&&d.issue.number!==r.number)throw Error('新任務編號不符');await deps.reload();}
export async function recoverTask(deps:any){if(!key)throw Error('請先登入');if(!taskWrites||!navigator.locks)throw Error('此版本尚未開放安全查回');const storageKey=key;return navigator.locks.request(storageKey,{ifAvailable:true},async lock=>{if(!lock)throw Error('其他分頁操作中');const m=taskPending();if(!m)return;await deps.verify();const g=deps.generation();const r=receipt(await deps.rpc('ownboard_owner_'+recovery[m.operation]+'_20261126_v1',{p_request_id:m.requestId,...(m.issueId?{p_issue_id:m.issueId}:{})}),m);await confirm(r,m,deps);if(g!==deps.generation())throw Error('登入已改變');localStorage.removeItem(storageKey);return r;});}
