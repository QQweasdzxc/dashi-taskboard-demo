/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
import {useEffect,useState} from 'react';
import {readCalendarMonth,currentSnapshot,statusLabel} from './connection';

export function projectCalendarMonth(d:any,month:string){
 if(d?.mode!=='read-only'||d.month!==month+'-01'||!Array.isArray(d.task_dates)||!Array.isArray(d.work_entries))throw Error('行事曆來源形狀或月份不符');
 const valid=(v:any)=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(new Date(v+'T00:00:00Z').getTime())&&new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v;
 const entries:any[]=[];const unplaced:any[]=[];
 for(const task of d.task_dates){const start=task.start_date,end=task.due_date;if((start&&!valid(start))||(end&&!valid(end))||(start&&end&&start>end)){unplaced.push({kind:'task',task});continue;}if(start&&end){entries.push({kind:'task',date:start,through:end,dateKind:'期間',crossMonth:start.slice(0,7)!==end.slice(0,7),task});}else if(start||end)entries.push({kind:'task',date:start||end,dateKind:start?'開始':'到期',task});else unplaced.push({kind:'task',task});}
 for(const entry of d.work_entries){if(!valid(entry.work_date)||!entry.work_date.startsWith(month+'-'))unplaced.push({kind:'worklog',entry});else entries.push({kind:'worklog',date:entry.work_date,entry});}
 return {entries:entries.sort((a,b)=>a.date.localeCompare(b.date)),unplaced};
}
export function TFCalendarRead(){
 const[month,setMonth]=useState(()=>new Date(Date.now()+8*3600000).toISOString().slice(0,7));
 const[data,setData]=useState<any>(null),[error,setError]=useState(''),[loading,setLoading]=useState(false);
 useEffect(()=>{let active=true;setLoading(true);setError('');setData(null);void readCalendarMonth(month).then(d=>{if(active)setData(projectCalendarMonth(d,month));}).catch(e=>{if(active)setError(String(e));}).finally(()=>{if(active)setLoading(false);});return()=>{active=false;};},[month]);
 return <main className="tf-calendar"><header><h1>行事曆與工時</h1><label>月份 <input type="month" value={month} min="1900-01" max="2200-12" onChange={e=>{if(/^\d{4}-\d{2}$/.test(e.target.value))setMonth(e.target.value);}}/></label></header><p className="tf-source-note">本人既有紀錄唯讀。任務日期與原 Worklog 同月顯示，工時不重算、不複製、不改名。此為月紀錄摘要，不含完整時段與狀態明細。</p>{loading&&<p role="status">正在讀取此月原紀錄…</p>}{error&&<p role="alert">{error}，未用空白或示範資料取代。</p>}{data&&<><p>{data.entries.length} 筆日期紀錄</p><section>{data.entries.map((x:any)=>x.kind==='task'?<article key={'task-'+x.task.id}><time>{x.dateKind} {x.date}{x.through&&x.through!==x.date?' 至 '+x.through:''}{x.crossMonth?'（跨月）':''}</time><span>任務</span><h2>{currentSnapshot().prefix}-{x.task.number} {x.task.title}</h2><p>{statusLabel(x.task.status)}</p></article>:<article key={'work-'+x.entry.id}><time>{x.date}</time><span>Worklog</span><h2>{x.entry.title}</h2><p>{String(x.entry.hours)} 小時</p>{x.entry.note&&<p>{x.entry.note}</p>}{x.entry.taskflow_issue_ref?.id&&<small>已保留原任務關聯 ID：{x.entry.taskflow_issue_ref.id}</small>}</article>)}</section>{data.entries.length===0&&<p>此月來源回傳沒有日期紀錄。</p>}{data.unplaced.length>0&&<p role="status">另有{data.unplaced.length}筆日期不完整或異常的原紀錄，未代填日期。</p>}</>}</main>;
}
