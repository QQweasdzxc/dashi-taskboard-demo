/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
import { fileURLToPath, URL } from "node:url";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  root: fileURLToPath(new URL(".", import.meta.url)),
  base: "./",
  plugins: [react()],
  build: {
    outDir: fileURLToPath(new URL("../dist/web-demo", import.meta.url)),
    emptyOutDir: true,
    assetsInlineLimit: 1024 * 1024 * 100,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
      },
    },
  },
});
