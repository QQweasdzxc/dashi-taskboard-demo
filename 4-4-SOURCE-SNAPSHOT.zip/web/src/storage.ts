/* Modified 2026-11-26 for the separate owner-gated Supabase read-only integration. Upstream Apache-2.0 retained; see SOURCE-AND-LICENSE.md. */
const memoryStorage = new Map<string, string>();
export const PROJECT_BOARD_DISPLAY_SETTINGS_KEY_PREFIX = "taskboard.project-board-display-settings.v3.";
const RETRY_DELAY_MS = 250;
const MAX_RETRY_DELAY_MS = 5_000;
let localStorageBackend: Storage | null = null;
let serverBacked = false;
let storageWrite = Promise.resolve();
let storageRefresh = Promise.resolve();

function isProjectBoardDisplaySettingsKey(key: string) {
  return key.startsWith(PROJECT_BOARD_DISPLAY_SETTINGS_KEY_PREFIX);
}

async function readServerStorage(){serverBacked=false;}
async function refreshServerStorage() {
  storageRefresh = storageRefresh.catch(() => {}).then(readServerStorage);
  await storageRefresh;
}

function persist(_key:string,_value:string|null) { /* Personal view prefs remain memory-only until approved. */ }
export async function initializeTaskboardStorage() {
  try {
    localStorageBackend = null;
  } catch {
    localStorageBackend = null;
  }
  await refreshServerStorage();
}

export async function refreshProjectBoardDisplaySettingsStorage() {
  await storageWrite;
  await refreshServerStorage();
}

export function projectBoardDisplaySettingsStorageEntries() {
  return [...memoryStorage.entries()].filter(([key]) => isProjectBoardDisplaySettingsKey(key));
}

export const taskboardStorage: Pick<Storage, "getItem" | "setItem" | "removeItem"> = {
  getItem(key) {
    if (isProjectBoardDisplaySettingsKey(key)) return memoryStorage.get(key) ?? null;
    return localStorageBackend?.getItem(key) ?? memoryStorage.get(key) ?? null;
  },
  setItem(key, value) {
    if (isProjectBoardDisplaySettingsKey(key)) {
      memoryStorage.set(key, value);
      persist(key, value);
      return;
    }
    if (localStorageBackend) {
      localStorageBackend.setItem(key, value);
      return;
    }
    memoryStorage.set(key, value);
    if (serverBacked) persist(key, value);
  },
  removeItem(key) {
    if (isProjectBoardDisplaySettingsKey(key)) {
      memoryStorage.delete(key);
      persist(key, null);
      return;
    }
    if (localStorageBackend) {
      localStorageBackend.removeItem(key);
      return;
    }
    memoryStorage.delete(key);
    if (serverBacked) persist(key, null);
  },
};
