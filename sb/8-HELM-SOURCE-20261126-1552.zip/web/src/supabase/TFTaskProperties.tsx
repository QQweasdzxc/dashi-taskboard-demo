/* HELM task-only controls, review candidate. Uses original TaskDetail save callbacks. */
import {useState,useEffect} from 'react';
import type {Task,TaskDraft} from '../types';
export function TFTaskProperties({task,onSave,locked=false}:{task:Task,onSave:(patch:Partial<TaskDraft>)=>Promise<unknown>,locked?:boolean}){
 const[busy,setBusy]=useState(false),[error,setError]=useState(''),[description,setDescription]=useState(task.description);
 useEffect(()=>setDescription(task.description),[task.id,task.description]);
 const save=(p:Partial<TaskDraft>)=>{if(busy||locked)return;setBusy(true);setError('');void onSave(p).catch(e=>setError(String(e))).finally(()=>setBusy(false));};
 return <section className="tf-task-properties" aria-label="基本任務編輯"><label>優先順序<select aria-label="編輯優先順序" value={task.priority} disabled={busy||locked} onChange={e=>save({priority:e.target.value as any})}>{[['none','無'],['urgent','緊急'],['high','高'],['medium','中'],['low','低']].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label><label>開始日期<input aria-label="編輯開始日期" type="date" value={task.startDate??''} disabled={busy||locked} onChange={e=>save({startDate:e.target.value||null})}/></label><label>到期日期<input aria-label="編輯到期日期" type="date" value={task.dueDate??''} disabled={busy||locked} onChange={e=>save({dueDate:e.target.value||null})}/></label><label className="tf-description-edit">描述<textarea aria-label="編輯原 TF 描述" value={description} disabled={busy||locked} onChange={e=>setDescription(e.target.value)}/><button disabled={busy||locked||description===task.description} onClick={()=>save({description})}>儲存描述</button></label>{error&&<p role="alert">{error}</p>}</section>;
}
