// HELM original TF typed properties, candidate only. No inferred options.
export type TFProperty={id:string,name:string,type:string,archived_at?:string|null,config?:{options?:{id:string,name:string,color:string}[]}};
export function normalizeTFProperty(def:TFProperty,value:unknown):unknown{
 const fail=():never=>{throw Error('自訂欄位值不符合原欄位定義');};
 const text=(v:unknown)=>{if(typeof v!=='string'||!v.trim()||[...v].length>2000)fail();return (v as string).replaceAll('\0','');};
 const url=(v:unknown)=>{if(typeof v!=='string')return fail();const s=v.trim();if(new TextEncoder().encode(s).length>2048)return fail();try{const u=new URL(s);if(!['http:','https:'].includes(u.protocol)||!u.host)return fail();}catch{return fail();}return s;};
 const actor=(v:unknown)=>{if(typeof v!=='string'||!v.startsWith('member:'))return fail();let id=v.slice(7);if(id.length===45&&id.slice(0,9).toLowerCase()==='urn:uuid:')id=id.slice(9);else if(id.length===38)id=id.slice(1,37);if(!/^([0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(id))return fail();id=id.replaceAll('-','').toLowerCase();return 'member:'+id.slice(0,8)+'-'+id.slice(8,12)+'-'+id.slice(12,16)+'-'+id.slice(16,20)+'-'+id.slice(20);};
 const list=(f:(v:unknown)=>unknown)=>{if(!Array.isArray(value)||!value.length||value.length>20)return fail();return [...new Set(value.map(f))];};
 switch(def.type){
 case 'text':return text(value);
 case 'url':return url(value);
 case 'number':if(typeof value!=='number'||!Number.isFinite(value))return fail();return value;
 case 'checkbox':if(typeof value!=='boolean')return fail();return value;
 case 'date':{if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return fail();const d=new Date(value+'T00:00:00Z');if(!Number.isFinite(+d)||d.toISOString().slice(0,10)!==value)return fail();return value;}
 case 'select':if(!def.config?.options?.some(o=>o.id===value))return fail();return value;
 case 'multi_select':{if(!Array.isArray(value)||!value.length)return fail();const options=def.config?.options||[];if(value.some(v=>typeof v!=='string'||!options.some(o=>o.id===v)))return fail();return options.filter(o=>value.includes(o.id)).map(o=>o.id);}
 case 'actor':return actor(value);
 case 'multi_actor':return list(actor);
 case 'multi_text':return list(text);
 case 'multi_url':return list(url);
 default:return fail();
 }
}
